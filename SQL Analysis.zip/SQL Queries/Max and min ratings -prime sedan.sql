# Find the maximum and minimum driver ratings for Prime Sedan bookings:
select * from ola.`bookings-20000-rows`;
select max(Driver_Ratings), min(Driver_Ratings) from ola.`bookings-20000-rows` where Vehicle_Type = "Prime Sedan";



