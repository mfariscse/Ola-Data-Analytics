# Get the number of rides cancelled by drivers due to personal and car-related issues
select * from ola.`bookings-20000-rows`;

select count(Booking_Status) from ola.`bookings-20000-rows` where Canceled_Rides_by_Driver = "Personal & Car related issue";