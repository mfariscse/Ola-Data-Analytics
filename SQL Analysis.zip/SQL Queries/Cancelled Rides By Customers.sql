# Get the total number of cancelled rides by customers:
select * from ola.`bookings-20000-rows`;

select count(*) from ola.`bookings-20000-rows` where Booking_Status = "Canceled by Customer";

