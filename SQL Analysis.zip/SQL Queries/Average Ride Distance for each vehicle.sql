#Find the average ride distance for each vehicle type:
select * from ola.`bookings-20000-rows`;

select avg(Ride_Distance) as `Average Ride Distance` from ola.`bookings-20000-rows`;
