# List all incomplete rides along with the reason:

select *  from ola.`bookings-20000-rows`;

SELECT Booking_ID, Incomplete_Rides_Reason FROM ola.`bookings-20000-rows` WHERE Incomplete_Rides = 'Yes';
