#  Find the average customer rating per vehicle type

select * from ola.`bookings-20000-rows`;

select Vehicle_Type, avg(Customer_Rating) as `Average Ratings` from ola.`bookings-20000-rows` group by Vehicle_Type;