# Retrieve all rides where payment was made using UPI

select * from ola.`bookings-20000-rows`;
select * from ola.`bookings-20000-rows` where Payment_Method = "UPI";