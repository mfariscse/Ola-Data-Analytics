# List the top 5 customers who booked the highest number of rides
select * from ola.`bookings-20000-rows`;
select * from ola.`bookings-20000-rows` order by Booking_Value desc limit 5;

SELECT Customer_ID, COUNT(Booking_ID) as total_rides FROM ola.`bookings-20000-rows` GROUP BY Customer_ID ORDER BY total_rides DESC LIMIT 5;