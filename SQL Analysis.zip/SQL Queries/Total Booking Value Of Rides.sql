# Calculate the total booking value of rides completed successfully:

select * from ola.`bookings-20000-rows`;

select sum(Booking_Value), Booking_Status from ola.`bookings-20000-rows` where Booking_Status = "Success";
