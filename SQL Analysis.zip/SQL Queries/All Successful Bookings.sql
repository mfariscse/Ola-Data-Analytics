# Retrieve all successful bookings
SELECT * FROM ola.`bookings-20000-rows`;

select * from ola.`bookings-20000-rows` where Booking_Status = "Success";
